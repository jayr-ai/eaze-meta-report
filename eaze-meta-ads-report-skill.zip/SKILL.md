---
name: eaze-meta-ads-report
description: Generate the Eaze Account 2 paid media report — a 12-section narrative Meta Ads performance report pulled live via the Meta MCP connector. Use this when asked to build, refresh, regenerate, or send the "Eaze Account 2" / act_797173066166825 Meta Ads report, or any report modeled on it.
---

# Eaze Account 2 — Meta Ads Paid Media Report

This Skill rebuilds the "AI Funding Solutions · Paid Media Report" for **Eaze | Account 2** (ad account id `797173066166825`, Business Manager "Eaze Consulting"). It is READ-ONLY: never call a mutating Meta MCP tool (`ads_create_*`, `ads_update_*`, `ads_activate_entity`, `ads_delete_*`, `ads_pixel_*_create/update/delete`) while running this Skill. Every number in the output must trace back to a real tool call — never invent or estimate a figure. Where Meta itself cannot return a number, say so explicitly instead of guessing (see "Not available" handling below).

## Before you start

1. Confirm the reporting window. **The cadence is a fixed Sunday-to-Saturday calendar week, not a rolling trailing period.** Always compute explicit `since`/`until` dates for the target window and pass them via `time_range` on every single call in the run — never use `date_preset: last_7d`. That preset is relative to the moment each call fires, so two calls made minutes apart (or across a slow multi-call run) can silently return different 7-day windows, which breaks reconciliation (this happened on the first live run: the account-level pull and the campaign-level pull landed on different windows because of exactly this).

   There are two distinct window types this Skill produces — pick based on what's being asked for:
   - **Completed-week recap:** the most recently fully-completed Sunday–Saturday week. Use when someone asks for "last week's report" or a specific past week by name/date.
   - **Day-to-day / current / on-demand request (the default for "give me the report" with no week specified):** **week-to-date** — `since` = the most recent Sunday on or before today, `until` = today. This is what leaders requesting the report "day to day" actually want: a live, accumulating picture of the current week that grows each day and resets every Sunday. Compute the most recent Sunday relative to the run date; do not hard-code a day count. If today itself is Sunday, the window is that single day.

   State plainly in the report which type of window this run used (completed week vs. week-to-date) — the two are not interchangeable and produce very different-looking reports (a 1–2 day week-to-date pull will have far less data than a completed week, and that is expected, not an error).
2. Note the pull timestamp and advertiser timezone (`PST8PDT` for this account) — this goes in the "Live data" status line and the footer.
3. Use `report-template.html` in this same folder as the structural reference. Reuse its CSS and class names exactly (sidebar nav, `.pill`, `.callout`, `.metric`, table styles, `.tag`, `ol.actions`) — do not restyle it.

## The known attribution caveat — expected, not an error

At the account level, `results` and `cost_per_result` will come back as `"Not available"` with the reason `"Results for this campaign were added together across different attribution settings"`. This is expected on this account (two result types run in parallel: appointments for med spa, leads for dentist/derma, on different attribution settings). Do not treat this as a failed call. Handle it by:
- Pulling `results` / `cost_per_result` at the **campaign** level instead, where each campaign has one consistent attribution setting.
- Stating the caveat plainly in the Data Trust section and the footer, exactly as the original report does: "Breakdown tables show spend and engagement only, not conversions, due to mixed attribution settings across campaigns."
- Never cross-comparing appointments and leads as if they were the same result type.

## Section-by-section build (tool → section mapping)

Pull in this order. Write the narrative for each section only after you have its real numbers in hand — never draft prose first and backfill numbers.

**01 — Account snapshot**
`ads_get_ad_entities`, `level: account`, `date_preset` per window, `fields: ["name","amount_spent","impressions","clicks","ctr","cpc","cpm","reach","frequency"]`.
Report: total spend, impressions/clicks/CTR, reach, frequency, objective, timezone, Business Manager name, account id.

**02 — Campaign performance**
`ads_get_ad_entities`, `level: campaign`, same window, `fields: ["name","amount_spent","impressions","clicks","ctr","cpc","results","cost_per_result"]`, `sort: amount_spent_descending`.
Rank campaigns by cost-per-result within each result type. Note the residual spend on any small/legacy paused campaigns not worth a full row (this is the "$10 on old paused duplicates" pattern from the original report) — reconcile it against the account-level total from section 01.

**03 — Ad performance**
`ads_get_ad_entities`, `level: ad`, same window, `fields: ["name","amount_spent","impressions","clicks","ctr","results","cost_per_result"]`, `sort: amount_spent_descending`. Show ads with meaningful spend (≥$20 in the original report); sum and state the count+combined spend of everything below that line rather than omitting it silently.

**04 — Creative & fatigue**
For the top 2–3 ads by spend or by result volume, call `ads_get_ad_entities` with `level: ad`, `time_increment: "1"` (daily breakdown), `fields: ["name","ctr","amount_spent"]` over the same window — or `ads_insights_performance_trend` with `analysis_level: AD`, `analysis_metric: CTR`, `entity_ids: [...]`. Write the verified day-by-day CTR trend, and call out explicitly whether an ad is plateauing, declining, or in early ramp — verified against real daily CTR, never against Meta's own trend labels.

**05 — Placement & platform**
Two calls (one breakdown per call, per the tool's limit): `breakdowns: ["publisher_platform"]` and `breakdowns: ["platform_position"]`, `fields: ["amount_spent","impressions","ctr","cpc","cpm"]`.

**06 — Device**
`breakdowns: ["impression_device"]`, `fields: ["amount_spent","ctr","cpc"]`.

**07 — Demographics**
Two separate calls: `breakdowns: ["age"]` and `breakdowns: ["gender"]`, `fields: ["amount_spent","ctr","cpc"]`.

**08 — Geography**
`breakdowns: ["region"]`, `fields: ["amount_spent","ctr","cpc"]`, `sort: amount_spent_descending`. Report the top 10 states/regions by spend only.

**09 — Dayparting**
`breakdowns: ["hourly_stats_aggregated_by_advertiser_time_zone"]`, `fields: ["amount_spent","ctr","cpc"]`. Cover the full 24 hours; call out the best-value and worst-value windows by name.

**10 — Data trust**
Use whatever pixel/dataset quality tools are available (`ads_get_dataset_quality`, `ads_get_dataset_stats`, `ads_pixel_event_read`) for the pixel(s) behind this account's Lead/Schedule/SubmitApplication events. Report match quality per event and what that means for trusting the cost-per-result numbers above. **If these tools don't return usable match-quality scores for this account, say so plainly in the report and flag it to JV as a gap to verify manually in Events Manager — do not invent a score.**

**11 — Opportunities**
`ads_get_opportunity_score`, `ad_account_id: "797173066166825"`. Report the score out of 100, compare to the prior report's score if you have it on hand, and list recommendations sorted by `opportunity_score_lift` (call these "points", per the tool's own guidance).

**12 — Action list**
Written last, synthesizing everything above into 6–8 numbered, specific recommendations (not generic advice) — reference exact ads/campaigns/numbers already pulled. Close with a one-line summary of the account's overall direction.

**00 — Executive summary + hero pills + callouts**
Write this last, once every section above is done. Pull the 3–4 biggest storylines (best engine, biggest drain, anything that changed structurally since the last report — e.g. a pause, a score jump). The hero pills are: spend/day, appointments, leads, blended cost/lead, blended cost/appointment.

## Reconciliation — do this before treating the report as done

- Sum of campaign-level spend (section 02) plus any noted residual/legacy spend must equal the account-level total spend (section 01) to the cent. If it doesn't tie out, find the missing campaign rather than adjusting a number to force a match.
- State the reconciled total explicitly in the footer: "Every table reconciles to the account total of $X to the cent."

## Footer — required on every run, adapt the dates/numbers only

Reuse this structure verbatim, filling in the real window/date/total:

> Reporting window [start] to [end], last fully settled 7 days, advertiser time zone PST8PDT. All figures pulled live from the Meta Marketing API for Eaze Account 2 (act_797173066166825) on [pull date/time]. Every table reconciles to the account total of $[total] to the cent. Breakdown tables show spend and engagement only, not conversions, due to mixed attribution settings across campaigns. Creative fatigue calls are verified against real day by day CTR, not Meta's trend labels. The last two to three days of the window are still settling under Meta's attribution lag, so appointment and lead counts are floors. Read only: nothing in the ad account was created, paused, edited or changed by this report.

## Lessons from the first live run (2026-07-06) — apply every time

- **Compute blended averages with real division, not rounded head-math.** The first run displayed $22.23 for blended cost-per-lead when $622.28 ÷ 28 actually rounds to $22.22. Always carry at least 4 decimal places through the division before rounding the final display value.
- **Define ad groupings once and reuse the exact same figure everywhere they're mentioned.** The first run described the same set of "dead" low-spend ads with two different totals ($170 in the executive summary, $240 in the action list) because the two sections listed slightly different ads. If a narrative references a group of ads/campaigns by a combined total, compute it once and cite that exact number and membership everywhere it appears.
- **Don't imply monotonic trends from two endpoints.** "Spend scaled from $X to $Y" implies steady movement — check the full daily series first; if it fluctuates, say so instead ("spend ranged between $X and $Y").
- **"Worst on both dimensions" claims need both dimensions checked.** A daypart/segment can have the worst CTR without having the worst CPC (or vice versa) — verify each claim against its own metric rather than assuming one bad number means everything about that row is the worst.
- **Distinguish a real prior run of this Skill from the one-off reference example it was built from.** Only frame a comparison as "vs. last report" once there are two genuine runs of this pipeline to compare. Until then, disclose explicitly that any comparison is against the original reference report, not a tracked prior period.

## Output

Fill `report-template.html`'s structure with the real content from this run (do not just edit the template file in place — write the result to a new/dated file, e.g. `eaze-account-2-report-YYYY-MM-DD.html`, so past runs stay available for comparison). Once JV has reviewed and reconciled a run, it can be deployed to Railway (see the operating guide's "Deploying things" playbook) and the link shared, e.g. via the twice-daily Slack automation already planned for this account.
